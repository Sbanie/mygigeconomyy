# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

CreatorOS is a South African creator economy tax compliance system. It's a React + TypeScript + Vite application that helps content creators, freelancers, and gig workers manage their income, expenses, invoicing, and SARS tax compliance.

## Development Commands

```bash
# Start development server
npm run dev

# Type checking (without emitting files)
npm run typecheck

# Linting
npm run lint

# Production build
npm run build

# Preview production build
npm run preview
```

## Architecture

### Tech Stack
- **Frontend**: React 18 with TypeScript
- **Build Tool**: Vite
- **Styling**: TailwindCSS with PostCSS
- **Backend**: Supabase (PostgreSQL + Auth)
- **Icons**: lucide-react

### Core Architecture Pattern

The application uses a **single-page navigation pattern** without React Router:
- Navigation is handled via state in [App.tsx](src/App.tsx) using `currentPage` state
- Pages are rendered conditionally in a switch statement
- The `Layout` component wraps all pages and provides the navigation sidebar
- Available pages: dashboard, income, expenses, invoices, tax, pricing, savings, learn, profile

### Authentication & State Management

**Authentication** is managed via React Context:
- [AuthContext.tsx](src/contexts/AuthContext.tsx) provides authentication state and methods
- Uses Supabase Auth for user management
- Profile data is loaded automatically on auth state changes
- The `useAuth()` hook provides: `user`, `profile`, `loading`, `signUp`, `signIn`, `signOut`, `refreshProfile`

### Onboarding Flow

**New User Onboarding** ([OnboardingFlow.tsx](src/components/OnboardingFlow.tsx)):
- After sign-up, users go through a 3-step onboarding process before accessing the dashboard
- Onboarding is required if `user_types.length === 0` or `platforms.length === 0`
- Steps:
  1. **Work Type Selection** - Choose from Creator Economy or Gig Economy categories (can select multiple)
  2. **Platform Selection** - Select all platforms where they earn income
  3. **Profile Details** - Set follower count (for creators), hourly rate, and monthly goals
- Data is saved to the `profiles` table and triggers dashboard access via `refreshProfile()`

### Database Structure

All database tables are defined in [supabase/migrations/20251026041403_create_creatorss_schema.sql](supabase/migrations/20251026041403_create_creatorss_schema.sql):

**Tables:**
- `profiles` - User profiles with SA-specific fields (tax number, VAT number, province, bank details)
- `income` - Income records with platform tracking and payment status
- `expenses` - SARS-compliant expense tracking with deductibility flags
- `invoices` - Invoice generation with line items and VAT calculations
- `savings_goals` - Financial goal tracking
- `tax_calculations` - Annual tax calculations with provisional tax payment tracking

**Security:**
- All tables have Row Level Security (RLS) enabled
- Users can only access their own data via `auth.uid() = user_id` policies
- All operations require authentication

### South African Tax Context

The application implements SARS (South African Revenue Service) tax calculations:

**Key Thresholds** (defined in [src/lib/constants.ts](src/lib/constants.ts)):
- Tax registration threshold: R95,750
- VAT registration threshold: R1,000,000
- Provisional tax threshold: R30,000 (non-PAYE income)
- Tax year: March 1 - February 28/29

**Tax Calculation** ([src/lib/taxCalculator.ts](src/lib/taxCalculator.ts)):
- `calculateSARSTax()` - Calculates tax based on SARS brackets
- `getComplianceStatus()` - Determines user's compliance status and required actions
- Progressive tax brackets from 0% (below threshold) to 45% (above R1,817,000)

### Component Organization

Components are feature-based in `src/components/`:
- `Auth.tsx` - Sign up/sign in forms with email confirmation support
- `OnboardingFlow.tsx` - 3-step onboarding wizard for new users
- `Dashboard.tsx` - Main dashboard with compliance status and quick actions
- `IncomeTracker.tsx` - Income recording and management
- `ExpenseTracker.tsx` - Expense tracking with deductibility
- `InvoiceSystem.tsx` - Invoice generation with SA bank details
- `TaxInsights.tsx` - Tax calculations and provisional tax tracking
- `PricingAssistant.tsx` - Pricing guidance for services
- `SavingsTracker.tsx` - Savings goals management
- `LearnHub.tsx` - Educational content about SARS compliance
- `ProfileManager.tsx` - User profile and tax information management
- `Layout.tsx` - Navigation sidebar wrapper

### Type System

All TypeScript types are centralized in [src/types/index.ts](src/types/index.ts):
- `UserProfile` - User profile with SA-specific fields
- `Income` - Income record with platform and payment tracking
- `Expense` - Expense with deductibility and VAT
- `Invoice` - Invoice with line items structure
- `LineItem` - Invoice line item
- `SavingsGoal` - Savings goal tracking
- `TaxCalculation` - Annual tax calculation results
- `ComplianceStatus` - Tax compliance status object

### Environment Configuration

Required environment variables (in `.env`):
- `VITE_SUPABASE_URL` - Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous key

## Important Patterns

### Supabase Client Usage

The Supabase client is initialized in [src/lib/supabase.ts](src/lib/supabase.ts). When working with database operations:

```typescript
import { supabase } from '../lib/supabase';

// Always use auth.uid() for user-specific queries
const { data } = await supabase
  .from('income')
  .select('*')
  .eq('user_id', user.id);
```

### Profile Data Access

Profile data should be accessed via the `useAuth()` hook, not by directly querying Supabase:

```typescript
const { profile, refreshProfile } = useAuth();

// After updating profile in database:
await refreshProfile();
```

### Currency and Formatting

All monetary values are in South African Rand (ZAR). Use `toLocaleString()` for display with proper formatting.

## South African Context

This application is specifically designed for the South African market:

### Work Type Categories

The app categorizes users into **Creator Economy** and **Gig Economy** segments ([src/lib/constants.ts](src/lib/constants.ts)):

**Creator Economy** (`CREATOR_TYPES`) - Monetize audiences and content:
- Social Media Influencers, Content Creators, YouTubers, Podcasters
- Writers, Bloggers, Newsletter Authors (Substack, Medium)
- Streamers, Gamers (Twitch, Kick)
- Online Educators, Coaches, Course Creators
- Digital Artists, Musicians, Designers

**Gig Economy** (`GIG_TYPES`) - Monetize skills and time:
- Creative Freelancers: Graphic Designers, Videographers, Photographers, Video Editors
- Digital Professionals: Developers, Digital Marketers, Copywriters, UX Designers
- On-Demand Workers: Uber/Bolt Drivers, Delivery Riders, TaskRabbit/SweepSouth Workers
- Skilled Artisans: Hairstylists, Makeup Artists, Tailors
- Virtual Assistants, Online Sellers, Consultants

**Hybrid "Pro-Creators"**: Users can select multiple categories to represent hybrid income streams.

### Platforms & Other SA-Specific Data

- **Platforms**: Social media (Instagram, TikTok, YouTube, etc.), Content platforms (Substack, Patreon), Gig platforms (Uber, Bolt, Upwork, Fiverr, Takealot)
- **Banking**: FNB, Capitec, Standard Bank, ABSA, Nedbank, etc.
- **Provinces**: All 9 SA provinces
- **Expense Categories**: SARS-compliant deductible expenses (home office max 50%, travel requires logbook)
- **Income Categories**: EFT, cash, barter/in-kind, sponsorship
- **Follower Ranges**: Nano (<1K), Micro (1K-10K), Mid-tier (10K-100K), Macro (100K-1M), Mega (1M+)

## Database Migration

Supabase migrations are in `supabase/migrations/`. To apply the schema:
1. Set up Supabase project
2. Link to project: `supabase link --project-ref <project-ref>`
3. Apply migrations: `supabase db push`

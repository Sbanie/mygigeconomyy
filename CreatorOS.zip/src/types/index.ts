export interface UserProfile {
  id: string;
  email: string;
  name: string;
  id_number?: string;
  user_types: string[];
  platforms: string[];
  follower_count: number;
  skills: string[];
  hourly_rate?: number;
  monthly_goal?: number;
  tax_number?: string;
  vat_number?: string;
  is_provisional_tax_payer: boolean;
  province?: string;
  bank_name?: string;
  account_number?: string;
  branch_code?: string;
  tax_status: 'below_threshold' | 'requires_registration' | 'registered' | 'vat_required';
  created_at: string;
  updated_at: string;
}

export interface Income {
  id: string;
  user_id: string;
  date: string;
  amount: number;
  platform: string;
  client: string;
  category: 'cash' | 'barter' | 'sponsorship' | 'eft';
  description: string;
  is_paid: boolean;
  invoice_id?: string;
  tax_withheld: number;
  created_at: string;
  updated_at: string;
}

export interface Expense {
  id: string;
  user_id: string;
  date: string;
  amount: number;
  category: string;
  is_deductible: boolean;
  description: string;
  receipt_url?: string;
  vat_amount: number;
  created_at: string;
  updated_at: string;
}

export interface LineItem {
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Invoice {
  id: string;
  user_id: string;
  client_name: string;
  client_email: string;
  client_vat_number?: string;
  invoice_number: string;
  date: string;
  due_date: string;
  line_items: LineItem[];
  subtotal: number;
  vat_amount: number;
  total: number;
  status: 'draft' | 'sent' | 'paid';
  bank_name?: string;
  account_number?: string;
  branch_code?: string;
  created_at: string;
  updated_at: string;
}

export interface SavingsGoal {
  id: string;
  user_id: string;
  name: string;
  target_amount: number;
  current_amount: number;
  target_date?: string;
  description?: string;
  created_at: string;
  updated_at: string;
}

export interface TaxCalculation {
  id: string;
  user_id: string;
  tax_year: string;
  annual_income: number;
  total_deductions: number;
  taxable_income: number;
  estimated_tax: number;
  tax_bracket: string;
  effective_rate: number;
  provisional_first_payment: number;
  provisional_second_payment: number;
  first_payment_paid: boolean;
  second_payment_paid: boolean;
  created_at: string;
  updated_at: string;
}

export interface ComplianceStatus {
  status: 'success' | 'warning' | 'urgent' | 'critical';
  message: string;
  action?: string;
  link?: string;
  guide?: boolean;
}
